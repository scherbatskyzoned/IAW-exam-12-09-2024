Tipo Email Password
Personal beatrice@gmail.com sonoBeatrice02
Personal eleonora@gmail.com sonoLele03
Personal elisa@gmail.com sonoElisa02
Cliente paolo@gmail.com sonoPaolo01
Cliente matteo@gmail.com sonoMatteo02
Cliente dalila@gmail.com sonoDalila02
-------------------------------------------
L'applicazione è responsive, è possibile utilizzarla tramite browser con qualsiasi dispositivo.
-------------------------------------------
Indirizzo sito: https://beatrice02castorina.pythonanywhere.com/